export const AccountMenu = () => import('../..\\components\\AccountMenu.vue' /* webpackChunkName: "components/account-menu" */).then(c => wrapFunctional(c.default || c))
export const AccountMenuMobile = () => import('../..\\components\\AccountMenuMobile.vue' /* webpackChunkName: "components/account-menu-mobile" */).then(c => wrapFunctional(c.default || c))
export const Breadcrumb = () => import('../..\\components\\Breadcrumb.vue' /* webpackChunkName: "components/breadcrumb" */).then(c => wrapFunctional(c.default || c))
export const CardProduct = () => import('../..\\components\\CardProduct.vue' /* webpackChunkName: "components/card-product" */).then(c => wrapFunctional(c.default || c))
export const CardProductMobile = () => import('../..\\components\\CardProductMobile.vue' /* webpackChunkName: "components/card-product-mobile" */).then(c => wrapFunctional(c.default || c))
export const CardProductSwiper = () => import('../..\\components\\CardProductSwiper.vue' /* webpackChunkName: "components/card-product-swiper" */).then(c => wrapFunctional(c.default || c))
export const Carousel1 = () => import('../..\\components\\Carousel1.vue' /* webpackChunkName: "components/carousel1" */).then(c => wrapFunctional(c.default || c))
export const Carousel2 = () => import('../..\\components\\Carousel2.vue' /* webpackChunkName: "components/carousel2" */).then(c => wrapFunctional(c.default || c))
export const Carousel3 = () => import('../..\\components\\Carousel3.vue' /* webpackChunkName: "components/carousel3" */).then(c => wrapFunctional(c.default || c))
export const Cart = () => import('../..\\components\\Cart.vue' /* webpackChunkName: "components/cart" */).then(c => wrapFunctional(c.default || c))
export const CartMobile = () => import('../..\\components\\CartMobile.vue' /* webpackChunkName: "components/cart-mobile" */).then(c => wrapFunctional(c.default || c))
export const Footer = () => import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const Footer2mobile = () => import('../..\\components\\Footer2mobile.vue' /* webpackChunkName: "components/footer2mobile" */).then(c => wrapFunctional(c.default || c))
export const Header = () => import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const HistoryTransactionItem = () => import('../..\\components\\HistoryTransactionItem.vue' /* webpackChunkName: "components/history-transaction-item" */).then(c => wrapFunctional(c.default || c))
export const LoadingSpinner = () => import('../..\\components\\LoadingSpinner.vue' /* webpackChunkName: "components/loading-spinner" */).then(c => wrapFunctional(c.default || c))
export const ModalDetailTransaksi = () => import('../..\\components\\ModalDetailTransaksi.vue' /* webpackChunkName: "components/modal-detail-transaksi" */).then(c => wrapFunctional(c.default || c))
export const ModalKonfirmasiBelanja = () => import('../..\\components\\ModalKonfirmasiBelanja.vue' /* webpackChunkName: "components/modal-konfirmasi-belanja" */).then(c => wrapFunctional(c.default || c))
export const ModalUlasan = () => import('../..\\components\\ModalUlasan.vue' /* webpackChunkName: "components/modal-ulasan" */).then(c => wrapFunctional(c.default || c))
export const NuxtLogo = () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const ProductCheckout = () => import('../..\\components\\ProductCheckout.vue' /* webpackChunkName: "components/product-checkout" */).then(c => wrapFunctional(c.default || c))
export const ProductCheckoutMobile = () => import('../..\\components\\ProductCheckoutMobile.vue' /* webpackChunkName: "components/product-checkout-mobile" */).then(c => wrapFunctional(c.default || c))
export const Rating = () => import('../..\\components\\Rating.vue' /* webpackChunkName: "components/rating" */).then(c => wrapFunctional(c.default || c))
export const RatingItem = () => import('../..\\components\\RatingItem.vue' /* webpackChunkName: "components/rating-item" */).then(c => wrapFunctional(c.default || c))
export const Search = () => import('../..\\components\\Search.vue' /* webpackChunkName: "components/search" */).then(c => wrapFunctional(c.default || c))
export const SearchMobile = () => import('../..\\components\\SearchMobile.vue' /* webpackChunkName: "components/search-mobile" */).then(c => wrapFunctional(c.default || c))
export const SwiperCardProduct = () => import('../..\\components\\SwiperCardProduct.vue' /* webpackChunkName: "components/swiper-card-product" */).then(c => wrapFunctional(c.default || c))
export const Tutorial = () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
export const Ulasan = () => import('../..\\components\\Ulasan.vue' /* webpackChunkName: "components/ulasan" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
