export { default as AccountMenu } from '../..\\components\\AccountMenu.vue'
export { default as AccountMenuMobile } from '../..\\components\\AccountMenuMobile.vue'
export { default as Breadcrumb } from '../..\\components\\Breadcrumb.vue'
export { default as CardProduct } from '../..\\components\\CardProduct.vue'
export { default as CardProductMobile } from '../..\\components\\CardProductMobile.vue'
export { default as CardProductSwiper } from '../..\\components\\CardProductSwiper.vue'
export { default as Carousel1 } from '../..\\components\\Carousel1.vue'
export { default as Carousel2 } from '../..\\components\\Carousel2.vue'
export { default as Carousel3 } from '../..\\components\\Carousel3.vue'
export { default as Cart } from '../..\\components\\Cart.vue'
export { default as CartMobile } from '../..\\components\\CartMobile.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Footer2mobile } from '../..\\components\\Footer2mobile.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as HistoryTransactionItem } from '../..\\components\\HistoryTransactionItem.vue'
export { default as ModalDetailTransaksi } from '../..\\components\\ModalDetailTransaksi.vue'
export { default as ModalKonfirmasiBelanja } from '../..\\components\\ModalKonfirmasiBelanja.vue'
export { default as ModalUlasan } from '../..\\components\\ModalUlasan.vue'
export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as ProductCheckout } from '../..\\components\\ProductCheckout.vue'
export { default as ProductCheckoutMobile } from '../..\\components\\ProductCheckoutMobile.vue'
export { default as Rating } from '../..\\components\\Rating.vue'
export { default as Search } from '../..\\components\\Search.vue'
export { default as SearchMobile } from '../..\\components\\SearchMobile.vue'
export { default as SwiperCardProduct } from '../..\\components\\SwiperCardProduct.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'
export { default as Ulasan } from '../..\\components\\Ulasan.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
