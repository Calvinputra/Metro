# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AccountMenu>` | `<account-menu>` (components/AccountMenu.vue)
- `<AccountMenuMobile>` | `<account-menu-mobile>` (components/AccountMenuMobile.vue)
- `<Breadcrumb>` | `<breadcrumb>` (components/Breadcrumb.vue)
- `<CardProduct>` | `<card-product>` (components/CardProduct.vue)
- `<CardProductMobile>` | `<card-product-mobile>` (components/CardProductMobile.vue)
- `<CardProductSwiper>` | `<card-product-swiper>` (components/CardProductSwiper.vue)
- `<Carousel1>` | `<carousel1>` (components/Carousel1.vue)
- `<Carousel2>` | `<carousel2>` (components/Carousel2.vue)
- `<Carousel3>` | `<carousel3>` (components/Carousel3.vue)
- `<Cart>` | `<cart>` (components/Cart.vue)
- `<CartMobile>` | `<cart-mobile>` (components/CartMobile.vue)
- `<Carttab>` | `<carttab>` (components/Carttab.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<Footer2mobile>` | `<footer2mobile>` (components/Footer2mobile.vue)
- `<Header>` | `<header>` (components/Header.vue)
- `<HistoryTransactionItem>` | `<history-transaction-item>` (components/HistoryTransactionItem.vue)
- `<LoadingSpinner>` | `<loading-spinner>` (components/LoadingSpinner.vue)
- `<ModalDetailTransaksi>` | `<modal-detail-transaksi>` (components/ModalDetailTransaksi.vue)
- `<ModalKonfirmasiBelanja>` | `<modal-konfirmasi-belanja>` (components/ModalKonfirmasiBelanja.vue)
- `<ModalTracking>` | `<modal-tracking>` (components/ModalTracking.vue)
- `<ModalTrackingItem>` | `<modal-tracking-item>` (components/ModalTrackingItem.vue)
- `<ModalUlasan>` | `<modal-ulasan>` (components/ModalUlasan.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<ProductCheckout>` | `<product-checkout>` (components/ProductCheckout.vue)
- `<ProductCheckoutMobile>` | `<product-checkout-mobile>` (components/ProductCheckoutMobile.vue)
- `<Rating>` | `<rating>` (components/Rating.vue)
- `<RatingItem>` | `<rating-item>` (components/RatingItem.vue)
- `<Search>` | `<search>` (components/Search.vue)
- `<SearchMobile>` | `<search-mobile>` (components/SearchMobile.vue)
- `<Searchtab>` | `<searchtab>` (components/Searchtab.vue)
- `<SwiperCardProduct>` | `<swiper-card-product>` (components/SwiperCardProduct.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<Ulasan>` | `<ulasan>` (components/Ulasan.vue)
