import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _f5f230e8 = () => interopDefault(import('..\\pages\\about_us.vue' /* webpackChunkName: "pages/about_us" */))
const _e48ad8a8 = () => interopDefault(import('..\\pages\\Berlangsung.vue' /* webpackChunkName: "pages/Berlangsung" */))
const _18730008 = () => interopDefault(import('..\\pages\\blank.vue' /* webpackChunkName: "pages/blank" */))
const _5f7f6f88 = () => interopDefault(import('..\\pages\\Cart.vue' /* webpackChunkName: "pages/Cart" */))
const _57ff0efe = () => interopDefault(import('..\\pages\\change_password.vue' /* webpackChunkName: "pages/change_password" */))
const _692a953c = () => interopDefault(import('..\\pages\\Checkout.vue' /* webpackChunkName: "pages/Checkout" */))
const _7d53bace = () => interopDefault(import('..\\pages\\contact_us.vue' /* webpackChunkName: "pages/contact_us" */))
const _37be0893 = () => interopDefault(import('..\\pages\\editprofile.vue' /* webpackChunkName: "pages/editprofile" */))
const _5c20326b = () => interopDefault(import('..\\pages\\forgot_password.vue' /* webpackChunkName: "pages/forgot_password" */))
const _9a3c6b0a = () => interopDefault(import('..\\pages\\Home.vue' /* webpackChunkName: "pages/Home" */))
const _e5cf2cb8 = () => interopDefault(import('..\\pages\\kebijakanprivasi.vue' /* webpackChunkName: "pages/kebijakanprivasi" */))
const _4fca4b9d = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _3c975426 = () => interopDefault(import('..\\pages\\menunggu_pembayaran.vue' /* webpackChunkName: "pages/menunggu_pembayaran" */))
const _0d0b7cf6 = () => interopDefault(import('..\\pages\\old_login.vue' /* webpackChunkName: "pages/old_login" */))
const _8f40a592 = () => interopDefault(import('..\\pages\\old_register.vue' /* webpackChunkName: "pages/old_register" */))
const _01ff25d4 = () => interopDefault(import('..\\pages\\old_test_modal.vue' /* webpackChunkName: "pages/old_test_modal" */))
const _3767c222 = () => interopDefault(import('..\\pages\\products\\index.vue' /* webpackChunkName: "pages/products/index" */))
const _fcdaa246 = () => interopDefault(import('..\\pages\\profile.vue' /* webpackChunkName: "pages/profile" */))
const _9184082a = () => interopDefault(import('..\\pages\\prosespesan.vue' /* webpackChunkName: "pages/prosespesan" */))
const _04a64c1f = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _47407b64 = () => interopDefault(import('..\\pages\\sampaitujuan.vue' /* webpackChunkName: "pages/sampaitujuan" */))
const _442fe938 = () => interopDefault(import('..\\pages\\sedangkirim.vue' /* webpackChunkName: "pages/sedangkirim" */))
const _15b29644 = () => interopDefault(import('..\\pages\\Selesai.vue' /* webpackChunkName: "pages/Selesai" */))
const _cc27798a = () => interopDefault(import('..\\pages\\tidakberhasil.vue' /* webpackChunkName: "pages/tidakberhasil" */))
const _46ceb5ab = () => interopDefault(import('..\\pages\\Undang.vue' /* webpackChunkName: "pages/Undang" */))
const _76c23c16 = () => interopDefault(import('..\\pages\\welcome.vue' /* webpackChunkName: "pages/welcome" */))
const _58d17241 = () => interopDefault(import('..\\pages\\wishlist.vue' /* webpackChunkName: "pages/wishlist" */))
const _fcdca91a = () => interopDefault(import('..\\pages\\pembayaran\\status\\_status.vue' /* webpackChunkName: "pages/pembayaran/status/_status" */))
const _70cc5bae = () => interopDefault(import('..\\pages\\pembayaran\\_uuid.vue' /* webpackChunkName: "pages/pembayaran/_uuid" */))
const _9e3835ec = () => interopDefault(import('..\\pages\\products\\_id.vue' /* webpackChunkName: "pages/products/_id" */))
const _64cfc281 = () => interopDefault(import('..\\pages\\reset_password\\_token.vue' /* webpackChunkName: "pages/reset_password/_token" */))
const _6861abd1 = () => interopDefault(import('..\\pages\\review_list\\_uuid.vue' /* webpackChunkName: "pages/review_list/_uuid" */))
const _0e68b6a2 = () => interopDefault(import('..\\pages\\riwayat_pembelian\\_filter.vue' /* webpackChunkName: "pages/riwayat_pembelian/_filter" */))
const _5103d3cc = () => interopDefault(import('..\\pages\\verify_email\\_token.vue' /* webpackChunkName: "pages/verify_email/_token" */))
const _f3baaef4 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about_us",
    component: _f5f230e8,
    name: "about_us"
  }, {
    path: "/Berlangsung",
    component: _e48ad8a8,
    name: "Berlangsung"
  }, {
    path: "/blank",
    component: _18730008,
    name: "blank"
  }, {
    path: "/Cart",
    component: _5f7f6f88,
    name: "Cart"
  }, {
    path: "/change_password",
    component: _57ff0efe,
    name: "change_password"
  }, {
    path: "/Checkout",
    component: _692a953c,
    name: "Checkout"
  }, {
    path: "/contact_us",
    component: _7d53bace,
    name: "contact_us"
  }, {
    path: "/editprofile",
    component: _37be0893,
    name: "editprofile"
  }, {
    path: "/forgot_password",
    component: _5c20326b,
    name: "forgot_password"
  }, {
    path: "/Home",
    component: _9a3c6b0a,
    name: "Home"
  }, {
    path: "/kebijakanprivasi",
    component: _e5cf2cb8,
    name: "kebijakanprivasi"
  }, {
    path: "/login",
    component: _4fca4b9d,
    name: "login"
  }, {
    path: "/menunggu_pembayaran",
    component: _3c975426,
    name: "menunggu_pembayaran"
  }, {
    path: "/old_login",
    component: _0d0b7cf6,
    name: "old_login"
  }, {
    path: "/old_register",
    component: _8f40a592,
    name: "old_register"
  }, {
    path: "/old_test_modal",
    component: _01ff25d4,
    name: "old_test_modal"
  }, {
    path: "/products",
    component: _3767c222,
    name: "products"
  }, {
    path: "/profile",
    component: _fcdaa246,
    name: "profile"
  }, {
    path: "/prosespesan",
    component: _9184082a,
    name: "prosespesan"
  }, {
    path: "/register",
    component: _04a64c1f,
    name: "register"
  }, {
    path: "/sampaitujuan",
    component: _47407b64,
    name: "sampaitujuan"
  }, {
    path: "/sedangkirim",
    component: _442fe938,
    name: "sedangkirim"
  }, {
    path: "/Selesai",
    component: _15b29644,
    name: "Selesai"
  }, {
    path: "/tidakberhasil",
    component: _cc27798a,
    name: "tidakberhasil"
  }, {
    path: "/Undang",
    component: _46ceb5ab,
    name: "Undang"
  }, {
    path: "/welcome",
    component: _76c23c16,
    name: "welcome"
  }, {
    path: "/wishlist",
    component: _58d17241,
    name: "wishlist"
  }, {
    path: "/pembayaran/status/:status?",
    component: _fcdca91a,
    name: "pembayaran-status-status"
  }, {
    path: "/pembayaran/:uuid?",
    component: _70cc5bae,
    name: "pembayaran-uuid"
  }, {
    path: "/products/:id",
    component: _9e3835ec,
    name: "products-id"
  }, {
    path: "/reset_password/:token?",
    component: _64cfc281,
    name: "reset_password-token"
  }, {
    path: "/review_list/:uuid?",
    component: _6861abd1,
    name: "review_list-uuid"
  }, {
    path: "/riwayat_pembelian/:filter?",
    component: _0e68b6a2,
    name: "riwayat_pembelian-filter"
  }, {
    path: "/verify_email/:token?",
    component: _5103d3cc,
    name: "verify_email-token"
  }, {
    path: "/",
    component: _f3baaef4,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
