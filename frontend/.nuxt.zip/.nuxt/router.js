import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _228f6f9e = () => interopDefault(import('..\\pages\\about_us.vue' /* webpackChunkName: "pages/about_us" */))
const _265834e7 = () => interopDefault(import('..\\pages\\Berlangsung.vue' /* webpackChunkName: "pages/Berlangsung" */))
const _49762cfa = () => interopDefault(import('..\\pages\\blank.vue' /* webpackChunkName: "pages/blank" */))
const _291dc361 = () => interopDefault(import('..\\pages\\Cart.vue' /* webpackChunkName: "pages/Cart" */))
const _3a239ab9 = () => interopDefault(import('..\\pages\\change_password.vue' /* webpackChunkName: "pages/change_password" */))
const _351c1607 = () => interopDefault(import('..\\pages\\Checkout.vue' /* webpackChunkName: "pages/Checkout" */))
const _f79c2404 = () => interopDefault(import('..\\pages\\contact_us.vue' /* webpackChunkName: "pages/contact_us" */))
const _5f48ac64 = () => interopDefault(import('..\\pages\\editprofile.vue' /* webpackChunkName: "pages/editprofile" */))
const _3e44be26 = () => interopDefault(import('..\\pages\\forgot_password.vue' /* webpackChunkName: "pages/forgot_password" */))
const _20f5556e = () => interopDefault(import('..\\pages\\kebijakanprivasi.vue' /* webpackChunkName: "pages/kebijakanprivasi" */))
const _7a32e7b0 = () => interopDefault(import('..\\pages\\menunggu_pembayaran.vue' /* webpackChunkName: "pages/menunggu_pembayaran" */))
const _118cb6b9 = () => interopDefault(import('..\\pages\\old_test_modal.vue' /* webpackChunkName: "pages/old_test_modal" */))
const _198c4ddd = () => interopDefault(import('..\\pages\\products\\index.vue' /* webpackChunkName: "pages/products/index" */))
const _50dfb4d0 = () => interopDefault(import('..\\pages\\profile.vue' /* webpackChunkName: "pages/profile" */))
const _4fdb9d26 = () => interopDefault(import('..\\pages\\prosespesan.vue' /* webpackChunkName: "pages/prosespesan" */))
const _6e57acc4 = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _57764873 = () => interopDefault(import('..\\pages\\sampaitujuan.vue' /* webpackChunkName: "pages/sampaitujuan" */))
const _7685ac9f = () => interopDefault(import('..\\pages\\sedangkirim.vue' /* webpackChunkName: "pages/sedangkirim" */))
const _6bb00cff = () => interopDefault(import('..\\pages\\Selesai.vue' /* webpackChunkName: "pages/Selesai" */))
const _fcb2fc94 = () => interopDefault(import('..\\pages\\tidakberhasil.vue' /* webpackChunkName: "pages/tidakberhasil" */))
const _7632116e = () => interopDefault(import('..\\pages\\tracking_test.vue' /* webpackChunkName: "pages/tracking_test" */))
const _438c08e0 = () => interopDefault(import('..\\pages\\Undang.vue' /* webpackChunkName: "pages/Undang" */))
const _66809a5e = () => interopDefault(import('..\\pages\\welcome.vue' /* webpackChunkName: "pages/welcome" */))
const _7afa5a34 = () => interopDefault(import('..\\pages\\wishlist.vue' /* webpackChunkName: "pages/wishlist" */))
const _a81912a4 = () => interopDefault(import('..\\pages\\pembayaran\\status\\_status.vue' /* webpackChunkName: "pages/pembayaran/status/_status" */))
const _36626f30 = () => interopDefault(import('..\\pages\\login\\_social_callback.vue' /* webpackChunkName: "pages/login/_social_callback" */))
const _5bfce4a9 = () => interopDefault(import('..\\pages\\pembayaran\\_uuid.vue' /* webpackChunkName: "pages/pembayaran/_uuid" */))
const _cec3b8f6 = () => interopDefault(import('..\\pages\\products\\_id.vue' /* webpackChunkName: "pages/products/_id" */))
const _91f6c334 = () => interopDefault(import('..\\pages\\reset_password\\_token.vue' /* webpackChunkName: "pages/reset_password/_token" */))
const _397b7b94 = () => interopDefault(import('..\\pages\\review_list\\_uuid.vue' /* webpackChunkName: "pages/review_list/_uuid" */))
const _41531807 = () => interopDefault(import('..\\pages\\riwayat_pembelian\\_filter.vue' /* webpackChunkName: "pages/riwayat_pembelian/_filter" */))
const _d3cf361e = () => interopDefault(import('..\\pages\\verify_email\\_token.vue' /* webpackChunkName: "pages/verify_email/_token" */))
const _48f49201 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about_us",
    component: _228f6f9e,
    name: "about_us"
  }, {
    path: "/Berlangsung",
    component: _265834e7,
    name: "Berlangsung"
  }, {
    path: "/blank",
    component: _49762cfa,
    name: "blank"
  }, {
    path: "/Cart",
    component: _291dc361,
    name: "Cart"
  }, {
    path: "/change_password",
    component: _3a239ab9,
    name: "change_password"
  }, {
    path: "/Checkout",
    component: _351c1607,
    name: "Checkout"
  }, {
    path: "/contact_us",
    component: _f79c2404,
    name: "contact_us"
  }, {
    path: "/editprofile",
    component: _5f48ac64,
    name: "editprofile"
  }, {
    path: "/forgot_password",
    component: _3e44be26,
    name: "forgot_password"
  }, {
    path: "/kebijakanprivasi",
    component: _20f5556e,
    name: "kebijakanprivasi"
  }, {
    path: "/menunggu_pembayaran",
    component: _7a32e7b0,
    name: "menunggu_pembayaran"
  }, {
    path: "/old_test_modal",
    component: _118cb6b9,
    name: "old_test_modal"
  }, {
    path: "/products",
    component: _198c4ddd,
    name: "products"
  }, {
    path: "/profile",
    component: _50dfb4d0,
    name: "profile"
  }, {
    path: "/prosespesan",
    component: _4fdb9d26,
    name: "prosespesan"
  }, {
    path: "/register",
    component: _6e57acc4,
    name: "register"
  }, {
    path: "/sampaitujuan",
    component: _57764873,
    name: "sampaitujuan"
  }, {
    path: "/sedangkirim",
    component: _7685ac9f,
    name: "sedangkirim"
  }, {
    path: "/Selesai",
    component: _6bb00cff,
    name: "Selesai"
  }, {
    path: "/tidakberhasil",
    component: _fcb2fc94,
    name: "tidakberhasil"
  }, {
    path: "/tracking_test",
    component: _7632116e,
    name: "tracking_test"
  }, {
    path: "/Undang",
    component: _438c08e0,
    name: "Undang"
  }, {
    path: "/welcome",
    component: _66809a5e,
    name: "welcome"
  }, {
    path: "/wishlist",
    component: _7afa5a34,
    name: "wishlist"
  }, {
    path: "/pembayaran/status/:status?",
    component: _a81912a4,
    name: "pembayaran-status-status"
  }, {
    path: "/login/:social_callback?",
    component: _36626f30,
    name: "login-social_callback"
  }, {
    path: "/pembayaran/:uuid?",
    component: _5bfce4a9,
    name: "pembayaran-uuid"
  }, {
    path: "/products/:id",
    component: _cec3b8f6,
    name: "products-id"
  }, {
    path: "/reset_password/:token?",
    component: _91f6c334,
    name: "reset_password-token"
  }, {
    path: "/review_list/:uuid?",
    component: _397b7b94,
    name: "review_list-uuid"
  }, {
    path: "/riwayat_pembelian/:filter?",
    component: _41531807,
    name: "riwayat_pembelian-filter"
  }, {
    path: "/verify_email/:token?",
    component: _d3cf361e,
    name: "verify_email-token"
  }, {
    path: "/",
    component: _48f49201,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
